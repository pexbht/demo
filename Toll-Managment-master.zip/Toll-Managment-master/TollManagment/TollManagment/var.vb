﻿Module var
    Public id As String
    Public pass As String
    Public ename As String
    Public type As String
    Public idbooth As String
End Module
