﻿Public Class VechileCharge_AddNew
    Private Sub VechileCharge_AddNew_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class